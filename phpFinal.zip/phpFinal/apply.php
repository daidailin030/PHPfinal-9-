<?php
$link=@mysqli_connect('localhost', //主機位置
'admin', //帳號
'root', //密碼
'calendar'); //資料庫名稱
$SQL="SELECT * FROM information;";
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="applyall.css">
  <title>報名表</title>
</head>
<body>

<div class="wrap">
  <div class="header">
  
    <ul class="menu">
       <li><a href="userindex.php">回創新學院行事曆</a></li>
      <li><a href="https://ifschool.nuk.edu.tw/workshop.php">回高大創新學院</a></li>
      <li><a href="https://www.nuk.edu.tw/bin/home.php">回高大首頁</a></li>
    </ul>
    <h1 class="logoname"><span class="i">I</span>magination for <span class="f">F</span>uture - School</h1> 
  </div>

  <div class="content">
   <h1 class="title">講座報名表單</h1>
   <div class="student">
<form action="applyfin.php" method="GET"> 
    <h2>1.學生姓名</h2>
     <input type="text" name="Name" style="border-style:none;width:200px; height:30px;" placeholder="輸入名字" ><br><hr width="60%"  align="left"><br>
     <h2>2.系級</h2><br>
     <input type="text" name="Level" style="border-style:none;width:200px; height:30px;" placeholder="輸入系級(ex:資管110)"><br><hr width="60%"  align="left">
     <h2>3.學號</h2><br>
     <input type="text" name="ID" style="border-style:none;width:200px; height:30px;" placeholder="輸入學號(字母請大寫)"><br><hr width="60%"  align="left">
     <h2>4.報名的課程/活動名</h2><br>
      <div class="select">
        <select name="Active">
          <option>請選擇</option>;
        <?php
        if($result=mysqli_query($link,$SQL)){
            while($row=mysqli_fetch_assoc($result)){
              echo "<option value='".$row["title"]."'>".$row["title"]." ".$row["start"]."</option>";
            }
        }
        echo "</select>";
        mysqli_close($link);
        ?>
        </select>
        <br>
        </div>
  </div>
  
  <div class="submit">
    <button  onclick="document.form.action='applyfin.php'" >提交報名</button>
  </div>
     <div class="reser">
       <button  onclick="document.form.action='applyfin.php'" >重新填寫</button>
     </div>
    
      
 </div>

</form>
  </div>
   
    
</div>
  
  
    
</body>
</html>
