<?php
$link=@mysqli_connect('localhost', //主機位置
                        'admin', //帳號
                        'root', //密碼
                        'calendar'); //資料庫名稱

session_start();
$counter = intval(file_get_contents("count.txt"));
if(isset($_SESSION[login2])){
if (!isset($_COOKIE['visitor'])) {
$counter++;
$fp = fopen("count.txt", "w");
flock($fp, LOCK_EX);   // do an exclusive lock
fwrite($fp, $counter);
flock($fp, LOCK_UN);   // release the lock
fclose($fp);
setcookie("visitor",1);
}

?>
<!DOCTYPE html>
<html>
 <head>
  <title>使用者行事曆介面</title>
  <link rel="stylesheet" href="calendar.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css" />
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.6/css/bootstrap.css" /> -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>
  <script>
   
  $(document).ready(function() {
   var calendar = $('#calendar').fullCalendar({
    editable:false,
    header:{
     left:'prev,next today',
     center:'title',
     right:'month,agendaWeek,agendaDay'
    },
    events: 'userload.php',
   });
  });
   
  </script>
 </head>
 <body>
  <div class="container">
  <div class="wrap">
  <div class="header">
    <img src="applyfin.png">
    <span class="if">IF School行事曆</span>
    <span class="year"><span class="month"></span></span>
  </div>

   <div class="clear"></div>
  <div class="menu">
    <ul>
      <li><a href="useractiveindex.php">個人行事曆</a></li>
      <li><a href="userindex.php">當月活動行事曆</a></li>
      <li><a href="apply.php">填寫報名表單</a></li>
      <li><a href="feedback.php">填寫回饋單</a></li>
      <li class="hot"><div class="hotz">熱門活動排名</div><br>
      <?php
                $i=1;
                $SQL="SELECT COUNT(Active), Active FROM apply GROUP BY Active HAVING COUNT(Active)>0 ORDER BY COUNT(Active) DESC LIMIT 3;";
                if($result=mysqli_query($link,$SQL)){
                    while($row=mysqli_fetch_assoc($result)){
                        echo $i."、".$row["Active"]."<br><br>";
                        $i++;
                    }
                }
                mysqli_close($link);
                ?>
                </li>
      <li class="hot"><div class="hotz">登入次數：
                <?php
                echo $counter."<br>";
                ?></div></li>
      <li><a href="login.php">回登入畫面</a></li>
    </ul>
  </div>
  <div class="content">
   <div id="calendar"></div>
  </div>
  </div>
 </body>
</html>

<?php    
}
else{
    echo "非法登入<br>";
    echo "<a href='login.php'>回登入畫面</a><br>";
}
?>