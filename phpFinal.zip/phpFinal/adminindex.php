<?php
$link=@mysqli_connect('localhost', //主機位置
'admin', //帳號
'root', //密碼
'calendar'); //資料庫名稱

session_start();
if(isset($_SESSION["login1"])){
$file_path = "count.txt";
if(file_exists($file_path)){
$str = file_get_contents($file_path);//將整個檔案內容讀入到一個字串中
}
?>
<!DOCTYPE html>
<html>
 <head>
  <title>管理者介面</title>
  <link rel="stylesheet" href="adminindexl.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css" />
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.6/css/bootstrap.css" /> -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>
  <script>
   
  $(document).ready(function() {
   var calendar = $('#calendar').fullCalendar({
    editable:true,
    header:{
     left:'prev,next today',
     center:'title',
     right:'month,agendaWeek,agendaDay'
    },
    events: 'load.php',
    selectable:true,
    selectHelper:true,
    select: function(start, end, allDay)
    {
     var title = prompt("Enter Event Title");
     if(title)
     {
      var url = prompt("Enter Event Url");
      if(url){
      var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
      var end = $.fullCalendar.formatDate(end, "Y-MM-DD HH:mm:ss");
            $.ajax({
         url:"insert.php",
         type:"POST",
         data:{title:title, start:start, end:end, url:url},
         success:function()
         {
          calendar.fullCalendar('refetchEvents');
          alert("Added Successfully");
         }
        })
       }
     }
    },
    editable:true,
    eventResize:function(event)
    {
     var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
     var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
     var title = event.title;
     var id = event.id;
     $.ajax({
      url:"update.php",
      type:"POST",
      data:{title:title, start:start, end:end, id:id},
      success:function(){
       calendar.fullCalendar('refetchEvents');
       alert('Event Updated');
      }
     })
    },

    eventDrop:function(event)
    {
     var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
     var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
     var title = event.title;
     var id = event.id;
     $.ajax({
      url:"update.php",
      type:"POST",
      data:{title:title, start:start, end:end, id:id},
      success:function()
      {
       calendar.fullCalendar('refetchEvents');
       alert("Event Updated");
      }
     });
    },

    eventRightClick:function()
    {
     if(confirm("Are you sure you want to remove it?"))
     {
      var id = event.id;
      $.ajax({
       url:"delete.php",
       type:"POST",
       data:{id:id},
       success:function()
       {
        calendar.fullCalendar('refetchEvents');
        alert("Event Removed");
       }
      })
     }
    },

   });
  });
   
   
  </script>
 </head>
 <!-- <body background="logo1.png"> -->
  <div class="container">
  <div class="wrap">
  <div class="header">
    <img src="applyfin.png">
    <span class="if">IF School行事曆</span>
    <span class="year"><span class="month"></span></span>
  </div>

   <div class="clear"></div>
  <div class="menu">
    <ul>
      <li><a href="adminindex.php">管理者行事曆</a></li>
      <li><a href="applyresult.php">活動報名管理</a></li>
      <li><a href="feedbackresult.php">回饋單管理</a></li>
      <li><a href="data.php">統計數據</a></li>
      <li class="hot"><div class="hotz">熱門活動排名</div><br>
      <?php
                $i=1;
                $SQL="SELECT COUNT(Active), Active FROM apply GROUP BY Active HAVING COUNT(Active)>0 ORDER BY COUNT(Active) DESC LIMIT 3;";
                if($result=mysqli_query($link,$SQL)){
                    while($row=mysqli_fetch_assoc($result)){
                        echo $i."、".$row["Active"]."<br><br>";
                        $i++;
                    }
                }
                mysqli_close($link);
                ?>
                </li>
      <li class="hot"><div class="hotz">使用者登入次數：
                <?php
                echo $str."<br>";
                ?></div></li>
      <li><a href="login.php">回登入畫面</a></li>
    </ul>
    
  </div>
  <div class="content">
   <div id="calendar"></div>
  </div>
  </div>
 </body>
</html>
<?php    
}
else{
    echo "非法登入<br>";
    echo "<a href='login.php'>回登入畫面</a><br>";
}
?>