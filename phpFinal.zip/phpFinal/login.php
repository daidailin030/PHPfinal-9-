<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="all.css">
    <title>Login page</title>
</head>
<body>
<div class="wrap">
    <ul class="menu">
      <li><a href="https://ifschool.nuk.edu.tw/workshop.php">回高大創新學院</a></li>
      <li><a href="https://www.nuk.edu.tw/bin/home.php">回高大首頁</a></li>
      <div class="clear"></div>
    </ul>
   
   
      <div class="header">
        <h1 class="logoname"><span class="i">I</span>magination for <span class="f">F</span>uture - School</h1> 
        <!-- <h1 class="nuk">高大創新學院</h1> -->
       

    </div>
      <div class="loginbox">
        <h2>創新學院行事曆登入</h2>
        <form action="check.php" method="POST">
        <?php
        if(isset($_COOKIE["uID"])){
            //如果cookie[uid]變數已經設置執行下面程式
            $uID=$_COOKIE['uID'];
            echo "ID:<input type='text' name='id' value=$uID><br/>";
            //之前如果已經登入過則直接將id顯示在上面
        
        }else{
            echo "<div class='user'><span>使用者帳號:</span>";
            echo "<input type='text' name='id'><br/></div>";
        }
        ?>
       <div class="passwd"> <span>使用者密碼:</span><input type="password" name="pwd" ><br></div>
       <input class="submit" type="submit">
       <input class="reset" type="reset">
       </form>
    </div>
    <div class="announcement">
      <h2>最新公告 NEWS <hr></h2>
      
      <ul>
        <li><a href="https://ifschool.nuk.edu.tw/newspost.php?nid=52">高雄大學、TXI Partners 攜手成立 全台大學第1所AVR+學校 培育體感科技人才</a><span>May 09,2019</span><hr></li>
        <li><a href="https://ifschool.nuk.edu.tw/newspost.php?nid=51">【創新學院課程】創新問題解決課程活動開放參加囉~ </a><span>May 09,2019</span><hr></li>
        <li><a href="https://ifschool.nuk.edu.tw/newspost.php?nid=50">【推薦活動】2019企業社會責任領航計畫-春季行動活動 </a><span>May 09,2019</span><hr></li>
        <li><a href="https://ifschool.nuk.edu.tw/newspost.php?nid=48">【107-2學期】3月超強敘事力簡報邏輯、表達微學分課程爆滿登場 </a><span>May 09,2019</span><hr></li>
        <li><a href="https://ifschool.nuk.edu.tw/newspost.php?nid=47">【創新學院】 107年第二屆電梯簡報競賽 </a><span>May 09,2019</span><hr></li>
        <li><a href="https://ifschool.nuk.edu.tw/newspost.php?nid=46">前進寶山原住民社區，活化廢棄校舍空間 </a><span>May 09,2019</span><hr></li>
      </ul>
    </div>

  </div>
  
</body>
</html>

<?php
session_start();
$click = intval(file_get_contents("click.txt"));
if (!isset($_COOKIE['click'])) {
$click++;
$fp1 = fopen("click.txt", "w");
flock($fp1, LOCK_EX);   // do an exclusive lock
fwrite($fp1, $click);
flock($fp1, LOCK_UN);   // release the lock
fclose($fp1);
setcookie("click",1,time()+10);
}
$_SESSION["click"]=$click;
unset($_SESSION["login1"]);
unset($_SESSION["login2"]);

setcookie("visitor", "", time()-3600);
?>
