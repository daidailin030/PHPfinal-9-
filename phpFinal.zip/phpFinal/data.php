<?php
$link=@mysqli_connect('localhost', //主機位置
'admin', //帳號
'root', //密碼
'calendar');

session_start();
if(isset($_SESSION["login1"])){
$file_path = "count.txt";
if(file_exists($file_path)){
$str = file_get_contents($file_path);//將整個檔案內容讀入到一個字串中
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>課程活動</title>
	<link rel="stylesheet" href="data.css">
</head>
<body background="logo1.png">
<div class="wrap">
  <div class="header">
    <img src="applyfin.png">
    <span class="if">IF School行事曆</span>
    <span class="year">課程活動列表<span class="month"></span>
  </div>

   <div class="clear"></div>
  <div class="menu">
  <ul>
      <li><a href="adminindex.php">管理者行事曆</a></li>
      <li><a href="applyresult.php">活動報名管理</a></li>
      <li><a href="feedbackresult.php">回饋單管理</a></li>
      <li><a href="data.php">統計數據</a></li>
      <li class="hot"><div class="hotz">熱門活動排名</div><br>
      <?php
                $i=1;
                $SQL="SELECT COUNT(Active), Active FROM apply GROUP BY Active HAVING COUNT(Active)>0 ORDER BY COUNT(Active) DESC LIMIT 3;";
                if($result=mysqli_query($link,$SQL)){
                    while($row=mysqli_fetch_assoc($result)){
                        echo $i."、".$row["Active"]."<br><br>";
                        $i++;
                    }
                }
                mysqli_close($link);
                ?>
                </li>
                <li class="hot"><div class="hotz">使用者登入次數：
                <?php
                echo $str."<br>";
                ?></div></li>
      <li><a href="login.php">回登入畫面</a></li>
    </ul>
  </div>
  <div class="content">
<?php
$link=@mysqli_connect('localhost', //主機位置
                        'admin', //帳號
                        'root', //密碼
                        'calendar'); //資料庫名稱


$filepath = "click.txt";
if(file_exists($filepath)){
$str1 = file_get_contents($filepath);//將整個檔案內容讀入到一個字串中
}
echo "<div class='click'>";  
echo "創新學院行事曆點擊次數：";
echo $str1;
echo "</div>";
echo "<div class='hr' style='width:550px;height:0px;border-top:1px black dashed;'></div>";
echo "<div class='active'>";


echo "活動報名統計<br><br>";
echo "<table border='1'>";
echo "<tr><td>課程活動</td><td>報名人數</td><td>報名餘額</td></tr>";
$SQL="SELECT title, COUNT(a.Active), maxlimit-COUNT(a.Active) FROM information i LEFT JOIN apply a ON i.title=a.Active GROUP BY i.title ORDER BY i.start";
if($result=mysqli_query($link,$SQL)){
    while($row=mysqli_fetch_assoc($result)){
        echo "<tr><td>".$row["title"]."</td><td>".$row["COUNT(a.Active)"]."</td><td>".$row["maxlimit-COUNT(a.Active)"]."</td></tr>";
    }
}
echo "</table>";

echo "</div>";
echo "</div>";
echo "</div>";

mysqli_close($link);

?>
<?php    
}
else{
    echo "非法登入<br>";
    echo "<a href='login.php'>回登入畫面</a><br>";
}
?>