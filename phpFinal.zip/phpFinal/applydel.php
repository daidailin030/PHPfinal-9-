
<?php
$link=@mysqli_connect('localhost', //主機位置
'admin', //帳號
'root', //密碼
'calendar'); //資料庫名稱

session_start();
if(isset($_SESSION["login1"])){
$file_path = "count.txt";
if(file_exists($file_path)){
$str = file_get_contents($file_path);//將整個檔案內容讀入到一個字串中
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>報名資料</title>
	<link rel="stylesheet" href="applyupdateresultl.css">
</head>
<body background="logo1.png">
<div class="wrap">
  <div class="header">
    <img src="applyfin.png">
    <span class="if">IF School行事曆</span>
    <span class="year">更新完成活動報名列表<span class="month"></span>
  </div>

   <div class="clear"></div>
  <div class="menu">
  <ul>
      <li><a href="adminindex.php">管理者行事曆</a></li>
      <li><a href="applyresult.php">活動報名管理</a></li>
      <li><a href="feedbackresult.php">回饋單管理</a></li>
      <li><a href="data.php">統計數據</a></li>
      <li class="hot"><div class="hotz">熱門活動排名</div><br>
      <?php
                $i=1;
                $SQL="SELECT COUNT(Active), Active FROM apply GROUP BY Active HAVING COUNT(Active)>0 ORDER BY COUNT(Active) DESC LIMIT 3;";
                if($result=mysqli_query($link,$SQL)){
                    while($row=mysqli_fetch_assoc($result)){
                        echo $i."、".$row["Active"]."<br><br>";
                        $i++;
                    }
                }
                mysqli_close($link);
                ?>
                </li>
      <li class="hot"><div class="hotz">使用者登入次數：
                <?php
                echo $str."<br>";
                ?></div></li>
      <li><a href="login.php">回登入畫面</a></li>
    </ul>
  </div>
  <div class="content">
  
<?php
$No=$_GET["No"];
$Name=$_GET["Name"];
$ID=$_GET["ID"];
$Level=$_GET["Level"];
$Active=$_GET["Active"];
$start=$_GET["start"];

$link=@mysqli_connect('localhost', //主機位置
                    'admin', //帳號
                    'root', //密碼
                    'calendar'); //資料庫名稱


$SQLDelete="DELETE FROM apply WHERE No=$No";
$result=mysqli_query($link,$SQLDelete);
$SQL="SELECT * FROM apply";
echo "<table>";
echo "<tr><td>名字</td><td>學號</td><td>系級</td><td>活動</td><td>時間</td><td>修改</td><td>刪除</td></tr>";
		if($result=mysqli_query($link,$SQL)){
			while($row=mysqli_fetch_assoc($result)){
			echo "<tr>";
			echo "<td>".$row["Name"]."</td><td>".$row["ID"]."</td><td>".$row["Level"]."</td><td>".$row["Active"]."</td><td>".$row["start"]."<td class='update'><a href='applyupdate.php?No=".$row["No"]."'>修改</a></td>"."<td class='del'>"."<a href='applydel.php?No=".$row["No"]."'>刪除<a></td>";
			echo "</tr>";
			}
		}
		echo "</table>";
	echo "</div>";
echo "</div>";

mysqli_close($link);

?>

	
</body>
</html>


<?php    
}
else{
    echo "非法登入<br>";
    echo "<a href='login.php'>回登入畫面</a><br>";
}
?>