<?php
$link=@mysqli_connect('localhost', //主機位置
'admin', //帳號
'root', //密碼
'calendar'); //資料庫名稱

session_start();
if(isset($_SESSION["login1"])){
$file_path = "count.txt";
if(file_exists($file_path)){
$str = file_get_contents($file_path);//將整個檔案內容讀入到一個字串中
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>報名資料</title>
	<link rel="stylesheet" href="feedbackdel.css">
</head>
<body background="logo1.png">
<div class="wrap">
  <div class="header">
    <img src="applyfin.png">
    <span class="if">IF School行事曆</span>
    <span class="year">更新完成活動回饋列表<span class="month"></span>
  </div>

   <div class="clear"></div>
  <div class="menu">
  <ul>
      <li><a href="adminindex.php">管理者行事曆</a></li>
      <li><a href="applyresult.php">活動報名管理</a></li>
      <li><a href="feedbackresult.php">回饋單管理</a></li>
      <li><a href="data.php">統計數據</a></li>
      <li class="hot"><div class="hotz">熱門活動排名</div><br>
      <?php
                $i=1;
                $SQL="SELECT COUNT(Active), Active FROM apply GROUP BY Active HAVING COUNT(Active)>0 ORDER BY COUNT(Active) DESC LIMIT 3;";
                if($result=mysqli_query($link,$SQL)){
                    while($row=mysqli_fetch_assoc($result)){
                        echo $i."、".$row["Active"]."<br><br>";
                        $i++;
                    }
                }
                mysqli_close($link);
                ?>
                </li>
      <li class="hot"><div class="hotz">登入次數：
                <?php
                echo $str."<br>";
                ?></div></li>
      <li><a href="login.php">回登入畫面</a></li>
    </ul>
  </div>
  <div class="content">
<?php
$No=$_GET["No"];
$Name=$_GET["Name"];
$ID=$_GET["ID"];
$Level=$_GET["Level"];
$Active=$_GET["Active"];
$Source=$_GET["Source"];
$whole=$_GET["whole"];
$content=$_GET["content"];
$teacher=$_GET["teacher"];
$message=$_GET["message"];

$link=@mysqli_connect('localhost', //主機位置
                    'admin', //帳號
                    'root', //密碼
                    'calendar'); //資料庫名稱

if($Name!=NULL && $ID!=NULL && $Level!=NULL && $Active!=NULL && $whole!=NULL && $content!=NULL && $teacher!=NULL){
    $SQLCreate="UPDATE feedback SET No='$No', ID='$ID', Name='$Name', Level='$Level', Active='$Active', Source='$Source', whole='$whole', content='$content', teacher='$teacher', message='$message' WHERE No=$No";
    $result=mysqli_query($link,$SQLCreate);
}
$SQL="SELECT * FROM feedback";

		echo "<table>";
		echo "<tr><td>學生姓名</td>"."<td>學號</td>"."<td>系級</td>"."<td>課程名稱</td>"."<td>資訊取得來源</td>"."<td>整體滿意度</td>"."<td>內容符合期望</td>"."<td>授課老師滿意度</td>"."<td>備註欄</td>"."<td>修改</td>"."<td>刪除</td></tr>";
		if($result=mysqli_query($link,$SQL)){
			while($row=mysqli_fetch_assoc($result)){
			echo "<tr>";
			echo "<td>".$row["Name"]."</td><td>".$row["ID"]."</td><td>".$row["Level"]."</td><td>".$row["Active"]."</td><td>".$row["Source"]."</td><td>".$row["whole"]."</td><td>".$row["content"]."</td><td>".$row["teacher"]."</td><td>".$row["message"]."</td><td class='update'><a href='feedbackupdate.php?No=" .$row["No"]."'>修改</a></td>"."<td class='del'>"."<a href='feedbackdel.php?No=".$row["No"]."'>刪除<a></td>";
			echo "</tr>";
			}
		}
		echo "</table>";
	echo "</div>";
echo "</div>";

mysqli_close($link);
?>
<?php    
}
else{
    echo "非法登入<br>";
    echo "<a href='login.php'>回登入畫面</a><br>";
}
?>