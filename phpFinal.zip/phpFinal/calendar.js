$(document).ready(function() {

  $('#calendar').fullCalendar({

    displayEventTime: false,
    timeFormat: 'H(:mm)',

    header: {
      left: 'prev,next today',
      center: 'title',
      right: 'month,agendaWeek,agendaDay'
    },

    allDayDefault: false,
    editable: true,
    droppable: true,

    eventRender: function(event, el) {

      el.find('.fc-content').html("<i class='fa fa-camera-retro fa-3x'></i>");

    },
    events: [{
      title: 'event1',
      start: '2017-01-01 06:44:00'
    }, {
      title: 'event2',
      start: '2017-01-01 06:50:00',
    }, {
      title: 'event3',
      start: '2017-02-01 10:50:00',
    }, {
      title: 'event3',
      start: '2017-02-01 12:50:00',
    }, {
      title: 'event3',
      start: '2017-02-01 13:50:00',
    }, ]
  })

});