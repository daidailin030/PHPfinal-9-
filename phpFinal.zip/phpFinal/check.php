
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="alll.css">
    <title>Login page</title>
</head>
<body>
<div class="wrap">
    <ul class="menu">
      <li><a href="https://ifschool.nuk.edu.tw/workshop.php">回高大創新學院</a></li>
      <li><a href="https://www.nuk.edu.tw/bin/home.php">回高大首頁</a></li>
      <div class="clear"></div>
    </ul>
   
   
      <div class="header">
        <h1 class="logoname"><span class="i">I</span>magination for <span class="f">F</span>uture - School</h1> 
        <!-- <h1 class="nuk">高大創新學院</h1> -->
       

    </div>
      <div class="loginboxf">
        <h2>創新學院行事曆登入失敗</h2>
        <?php
session_start();
$myid=$_POST["id"];
$myPass=$_POST["pwd"];

if($myid=="admin" && $myPass=="root"){
    $_SESSION["login1"]="success";
    header("location:adminindex.php");
}
elseif ($myid=="A1063304" && $myPass=="free"){
    $_SESSION["login2"]="success";
    header("location:useractiveindex.php");
}
else{
    $_SESSION["loginfail"]="fail";
    echo "帳號密碼錯誤，請再試一次<p><br><br>";
    echo "<a href='login.php'>回首頁</a><br><br><br><br>";
}
?>
        
    </div>
    

  </div>
  
</body>
</html>