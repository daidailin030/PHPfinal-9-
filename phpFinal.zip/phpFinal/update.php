<?php

//update.php

$connect = new PDO('mysql:host=localhost;dbname=evenement', 'root', 'ha310239');

if(isset($_POST["id"]))
{
 $query = "
 UPDATE event 
 SET title=:title, start=:start, end=:end , url=:url 
 WHERE id=:id
 ";
 $statement = $connect->prepare($query);
 $statement->execute(
  array(
   ':title'  => $_POST['title'],
   ':start' => $_POST['start'],
   ':end' => $_POST['end'],
   ':url' => $_POST['url'],
   ':id'   => $_POST['id']
  )
 );
}

?>

