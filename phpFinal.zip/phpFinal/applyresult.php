<?php
session_start();
$Name=$_SESSION["Name"];
$ID=$_SESSION["ID"];
$Level=$_SESSION["Level"];
$Active=$_SESSION["Active"];
$start=$_SESSION["start"];

$link=@mysqli_connect('localhost', //主機位置
'admin', //帳號
'root', //密碼
'calendar');

if(isset($_SESSION["login1"])){
$file_path = "count.txt";
if(file_exists($file_path)){
$str = file_get_contents($file_path);//將整個檔案內容讀入到一個字串中
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>報名資料</title>
	<link rel="stylesheet" href="applyresult.css">
</head>
<body background="logo1.png">
<div class="wrap">
  <div class="header">
    <img src="applyfin.png">
    <span class="if">IF School行事曆</span>
    <span class="year">活動報名列表<span class="month"></span>
  </div>

   <div class="clear"></div>
  <div class="menu">
  <ul>
    <li><a href="adminindex.php">管理者行事曆</a></li>
      <li><a href="applyresult.php">活動報名管理</a></li>
      <li><a href="feedbackresult.php">回饋單管理</a></li>
      <li><a href="data.php">統計數據</a></li>
      <li class="hot"><div class="hotz">熱門活動排名</div><br>
      <?php
                $i=1;
                $SQL="SELECT COUNT(Active), Active FROM apply GROUP BY Active HAVING COUNT(Active)>0 ORDER BY COUNT(Active) DESC LIMIT 3;";
                if($result=mysqli_query($link,$SQL)){
                    while($row=mysqli_fetch_assoc($result)){
                        echo $i."、".$row["Active"]."<br><br>";
                        $i++;
                    }
                }
                ?>
                </li>
      <li class="hot"><div class="hotz">使用者登入次數：
                <?php
                echo $str."<br>";
                ?></div></li>
      <li><a href="login.php">回登入畫面</a></li>
    </ul>
  </div>
  <div class="content">
  

<?php


$SQL="SELECT * FROM apply";

    echo "<table>";
    echo "<td>名字</td><td>學號</td><td>系級</td><td>活動</td><td>時間</td><td>修改</td><td>刪除</td>";
		if($result=mysqli_query($link,$SQL)){
			while($row=mysqli_fetch_assoc($result)){
			echo "<tr>";
			echo "<td>".$row["Name"]."</td><td>".$row["ID"]."</td><td>".$row["Level"]."</td><td>".$row["Active"]."</td><td>".$row["start"]."<td class='update'><a href='applyupdate.php?No=".$row["No"]."'>修改</a></td>"."<td class='del'>"."<a href='applydel.php?No=".$row["No"]."'>刪除<a></td>";
			echo "</tr>";
			}
		}
		echo "</table>";
	echo "</div>";
echo "</div>";

mysqli_close($link);
unset($_SESSION["Name"]);
unset($_SESSION["ID"]);
unset($_SESSION["Active"]);
unset($_SESSION["start"]);
unset($_SESSION["Level"]);


?>

	
</body>
</html>
<?php    
}
else{
    echo "非法登入<br>";
    echo "<a href='login.php'>回登入畫面</a><br>";
}
?>