<?php
session_start();

$_SESSION["Name"]=$_GET["Name"];
$_SESSION["Level"]=$_GET["Level"];
$_SESSION["ID"]=$_GET["ID"];
$_SESSION["Active"]=$_GET["Active"];

$Name=$_SESSION["Name"];
$ID=$_SESSION["ID"];
$Level=$_SESSION["Level"];
$Active=$_SESSION["Active"];
$start=$_SESSION["start"];

$link=@mysqli_connect('localhost', //主機位置
'admin', //帳號
'root', //密碼
'calendar'); //資料庫名稱

if($Name!=NULL && $ID!=NULL && $Level!=NULL && $Active!=NULL){
  $SQLCreate="INSERT into apply(ID, Name, Level, Active, start) VALUES ('$ID', '$Name', '$Level', '$Active', '$start')";
  $result=mysqli_query($link,$SQLCreate);
}

$SQL="SELECT start FROM information WHERE title='".$_SESSION["Active"]."'";
if($result=mysqli_query($link,$SQL)){
  while($row=mysqli_fetch_assoc($result)){
    $start=$row["start"];
  }
}
$_SESSION["start"]=$start;

if(isset($_SESSION["login2"])){
  $file_path = "count.txt";
  if(file_exists($file_path)){
  $str = file_get_contents($file_path);//將整個檔案內容讀入到一個字串中
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="applyfin.css">
    <title>使用者行事曆介面</title>
</head>

<body background="logo1.png">
  
    
<div class="wrap">
  <div class="header">
    <img src="applyfin.png">
    <span class="if">IF School行事曆</span>
     <span class="year">此活動已更新到個入行事曆<span class="month"></span></span> 
  </div>

   <div class="clear"></div>
  <div class="menu">
    <ul>
      <li><a href="useractiveindex.php">個人行事曆</a></li>
      <li><a href="userindex">當月活動行事曆</a></li>
      <li><a href="apply.php">填寫報名表單</a></li>
      <li><a href="feedback.php">填寫回饋單</a></li>
      <li class="hot"><div class="hotz">熱門活動排名</div><br>
      <?php
                $i=1;
                $SQL="SELECT COUNT(Active), Active FROM apply GROUP BY Active HAVING COUNT(Active)>0 ORDER BY COUNT(Active) DESC LIMIT 3;";
                if($result=mysqli_query($link,$SQL)){
                    while($row=mysqli_fetch_assoc($result)){
                        echo $i."、".$row["Active"]."<br><br>";
                        $i++;
                    }
                }
                mysqli_close($link);
                ?>
                </li>
      <li class="hot"><div class="hotz">登入次數：
                <?php
                echo $str."<br>";
                ?></div></li>
      <li><a href="login.php">回登入畫面</a></li>
      <li><a href="https://ifschool.nuk.edu.tw/workshop.php">回高大創新學院</a></li>
      <li><a href="https://www.nuk.edu.tw/bin/home.php">回高大首頁</a></li>
    </ul>
  </div>
  <div class="content">
  <div class="title">活動報名完成,記得去參加哦！</div>
  <div class="uldetail">
  <ul>
    <?php

echo "<li>名字：".$_GET["Name"]."</li>";
echo "<li>系級：".$_GET["Level"]."</li>";
echo "<li>學號：".$_GET["ID"]."</li>";
echo "<li>活動：".$_GET["Active"]." ".$start."</li>";
echo "<li></li>";
?>
    
    </ul>
    </div> 
  </div>

</div>
</body>
</html>
<?php    
}
else{
    echo "非法登入<br>";
    echo "<a href='login.php'>回登入畫面</a><br>";
}
?>