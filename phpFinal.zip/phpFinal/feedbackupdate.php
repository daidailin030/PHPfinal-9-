
<?php
$link=@mysqli_connect('localhost', //主機位置
'admin', //帳號
'root', //密碼
'calendar'); //資料庫名稱

session_start();
if(isset($_SESSION["login1"])){
$file_path = "count.txt";
if(file_exists($file_path)){
$str = file_get_contents($file_path);//將整個檔案內容讀入到一個字串中
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>回饋資料更新</title>
	<link rel="stylesheet" href="feedbackupdate.css">
</head>
<body background="logo1.png">
<div class="wrap">
  <div class="header">
    <img src="applyfin.png">
    <span class="if">IF School行事曆</span>
    <span class="year">回饋資料更新<span class="month"></span>
  </div>

   <div class="clear"></div>
  <div class="menu">
  <ul>
      <li><a href="adminindex.php">管理者行事曆</a></li>
      <li><a href="applyresult.php">活動報名管理</a></li>
      <li><a href="feedbackresult.php">回饋單管理</a></li>
      <li><a href="data.php">統計數據</a></li>
      <li class="hot"><div class="hotz">熱門活動排名</div><br>
      <?php
                $i=1;
                $SQL="SELECT COUNT(Active), Active FROM apply GROUP BY Active HAVING COUNT(Active)>0 ORDER BY COUNT(Active) DESC LIMIT 3;";
                if($result=mysqli_query($link,$SQL)){
                    while($row=mysqli_fetch_assoc($result)){
                        echo $i."、".$row["Active"]."<br><br>";
                        $i++;
                    }
                }
                mysqli_close($link);
                ?>
                </li>
      <li class="hot"><div class="hotz">登入次數：
                <?php
                echo $str."<br>";
                ?></div></li>
      <li><a href="login.php">回登入畫面</a></li>
    </ul>
  </div>
  <div class="content">
    <div class="detail">
<?php
$Name=$_GET["Name"];
$ID=$_GET["ID"];
$Level=$_GET["Level"];
$Active=$_GET["Active"];
$Source=$_GET["Source"];
$whole=$_GET["whole"];
$content=$_GET["content"];
$teacher=$_GET["teacher"];
$message=$_GET["message"];
$No=$_GET["No"];
$link=@mysqli_connect('localhost', //主機位置
                    'admin', //帳號
                    'root', //密碼
                    'calendar'); //資料庫名稱

$SQLUpdate="SELECT * FROM feedback WHERE No=$No";

        if($result=mysqli_query($link,$SQLUpdate)){
            while($row=mysqli_fetch_assoc($result)){
                echo "<form action='feedbackupdateresult.php' method='GET'>";
                echo "編號：".$row["No"]."<br>";
                echo "<input type='hidden' name='No' value=".$row["No"]."><br>";
                echo "姓名：<input type='text' name='Name' value=".$row["Name"]."><br>";
                echo "學號：<input type='text' name='ID' value=".$row["ID"]."><br>";
                echo "系級：<input type='text' name='Level' value=".$row["Level"]."><br>";
                echo "課程活動：<input type='text' name='Active' value=".$row["Active"]."><br>";
                echo "資訊取得來源：<input type='text' name='Source' value=".$row["Source"]."><br>";
                echo "整體滿意度：<input type='text' name='whole' value=".$row["whole"]."><br>";
                echo "內容符合期望：<input type='text' name='content' value=".$row["content"]."><br>";
                echo "授課老師滿意度：<input type='text' name='teacher' value=".$row["teacher"]."><br>";
                echo "備註欄：<input type='text' name='message' value=".$row["message"]."><br>";
            
          
		}
		}
		


mysqli_close($link);
?>
</div>
<div class="submit">
    <button  onclick="form.submit()" >提交更新</button>
  </div>
  <div class="reser">
       <button  onclick="form.reset()" >重新填寫</button>
     </div>

    </form>

</div>
</div>
	
</body>
</html>
<?php    
}
else{
    echo "非法登入<br>";
    echo "<a href='login.php'>回登入畫面</a><br>";
}
?>