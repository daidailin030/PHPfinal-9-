<?php
session_start();

$_SESSION["Name1"]=$_GET["Name"];
$_SESSION["Level1"]=$_GET["Level"];
$_SESSION["ID1"]=$_GET["ID"];
$_SESSION["Active1"]=$_GET["Active"];
$_SESSION["Source"]=$_GET["Source"];
$_SESSION["whole"]=$_GET["whole"];
$_SESSION["content"]=$_GET["content"];
$_SESSION["teacher"]=$_GET["teacher"];
$_SESSION["message"]=$_GET["message"];

$link=@mysqli_connect('localhost', //主機位置
'admin', //帳號
'root', //密碼
'calendar'); //資料庫名稱

if(isset($_SESSION["login2"])){
$file_path = "count.txt";
if(file_exists($file_path)){
$str = file_get_contents($file_path);//將整個檔案內容讀入到一個字串中
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="applyfin.css">
    <title>Document</title>
</head>
<body background="logo1.png">
    
<div class="wrap">
  <div class="header">
    <img src="applyfin.png">
    <span class="if">IF School行事曆</span>
    
  </div>

   <div class="clear"></div>
  <div class="menu">
  <ul>
      <li><a href="userindex.php">個人行事曆</a></li>
      <li><a href="#">當月活動行事曆</a></li>
      <li><a href="apply.php">填寫報名表單</a></li>
      <li><a href="feedback.php">填寫回饋單</a></li>
      <li class="hot"><div class="hotz">熱門活動排名</div><br>
      <?php
                $i=1;
                $SQL="SELECT COUNT(Active), Active FROM apply GROUP BY Active HAVING COUNT(Active)>0 ORDER BY COUNT(Active) DESC LIMIT 3;";
                if($result=mysqli_query($link,$SQL)){
                    while($row=mysqli_fetch_assoc($result)){
                        echo $i."、".$row["Active"]."<br><br>";
                        $i++;
                    }
                }
                mysqli_close($link);
                ?>
                </li>
      <li class="hot"><div class="hotz">登入次數：
                <?php
                echo $str."<br>";
                ?></div></li>
      <li><a href="login.php">回登入畫面</a></li>
      <li><a href="https://ifschool.nuk.edu.tw/workshop.php">回高大創新學院</a></li>
      <li><a href="https://www.nuk.edu.tw/bin/home.php">回高大首頁</a></li>
    </ul>
  </div>
  <div class="content">
  <div class="title">感謝你的回饋!</div>
    <ul>
    <?php

echo "<li>名字：".$_GET["Name"]."</li>";
echo "<li>系級：".$_GET["Level"]."</li>";
echo "<li>學號：".$_GET["ID"]."</li>";
echo "<li>課程/活動名：".$_GET["Active"]."</li>";
echo "<li>資訊取得來源：".$_GET["Source"]."</li>";
echo "<li>整體滿意度：".$_GET["whole"]."</li>";
echo "<li>內容符合期望：".$_GET["content"]."</li>";
echo "<li>授課老師滿意度：".$_GET["teacher"]."</li>";
echo "<li>備註欄：".$_GET["message"]."</li>";
?>
    
    </ul>
    
  </div>
</div>
</body>
</html>
<?php    
}
else{
    echo "非法登入<br>";
    echo "<a href='login.php'>回登入畫面</a><br>";
}
?>