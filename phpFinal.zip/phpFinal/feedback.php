<?php
$link=@mysqli_connect('localhost', //主機位置
                        'admin', //帳號
                        'root', //密碼
                        'calendar'); //資料庫名稱
$SQL="SELECT DISTINCT Active FROM apply WHERE ID='A1063304';";
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="feedbackall.css">
  <title>回饋表單</title>
</head>
<body>

<div class="wrap">
  <div class="header">
    <ul class="menu">
       <li><a href="userindex.php">回創新學院行事曆</a></li>
      <li><a href="https://ifschool.nuk.edu.tw/workshop.php">回高大創新學院</a></li>
      <li><a href="https://www.nuk.edu.tw/bin/home.php">回高大首頁</a></li>
    </ul>
    <div class="clear"></div>
    <h1 class="logoname"><span class="i">I</span>magination for <span class="f">F</span>uture - School</h1> 
  </div>
  
  <div class="content">
   <h1 class="title">回饋表單</h1>
   <div class="student">
<form action="feedbackfin.php" method="GET"> 
     <h2>1.學生姓名</h2>
     <input type="text" name="Name" style="border-style:none;width:200px; height:30px;" placeholder="輸入名字"><br><hr width="60%"  align="left">
     <h2>2.系級</h2>
     <input type="text" name="Level" style="border-style:none;width:200px; height:30px;" placeholder="輸入系級(ex:110)"><br><hr width="60%"  align="left">
     <h2>3.學號</h2>
     <input type="text" name="ID" style="border-style:none;width:200px; height:30px;" placeholder="輸入學號(字母請大寫)"><br><hr width="60%"  align="left">
       <h2>4.報名的課程/活動名</h2>
      <div class="select">
        <select name="Active">
        <?php
        if($result=mysqli_query($link,$SQL)){
            while($row=mysqli_fetch_assoc($result)){
              echo "<option value='".$row["Active"]."'>".$row["Active"]." ".$row["start"]."</option>";
            }
        }
        mysqli_close($link);
        ?>
          
        </select>
        <br>
        </div>
  <hr width="60%"  align="left">
    <h2 >5.資訊取得來源</h2>
    <div class="space">
    <input type="radio" name="Source" value="創新學院官網">創新學院官網   
        <input type="radio" name="Source" value="FB粉絲專頁">FB粉絲專頁
        <input type="radio" name="Source" value="宣傳海報">宣傳海報
        <input type="radio" name="Source" value="師生介紹">師生介紹
 
    </div>
    <hr width="80%"  align="left">

  <h2>6.整體滿意度</h2>
  <div class="space">
  <input  type="radio" name="whole" value="非常滿意">非常滿意   
        <input  type="radio" name="whole" value="滿意">滿意   
        <input  type="radio" name="whole" value="普通">普通   
        <input  type="radio" name="whole" value="不滿意">不滿意   
        <input  type="radio" name="whole" value="非常不滿意">非常不滿意
  </div>
  
  <hr width="80%"  align="left">
  <h2>7.內容符合期望</h2>
  <div class="space">
  <input  type="radio" name="content" value="非常滿意">非常滿意   
        <input  type="radio" name="content" value="滿意">滿意   
        <input  type="radio" name="content" value="普通">普通   
        <input  type="radio" name="content" value="不滿意">不滿意   
        <input  type="radio" name="content" value="非常不滿意">非常不滿意
  </div>
  
  <hr width="80%"  align="left">
  <h2>8.授課老師滿意度</h2>
  <div class="space">
  <input  type="radio" name="teacher" value="非常滿意">非常滿意   
        <input  type="radio" name="teacher" value="滿意">滿意   
        <input  type="radio" name="teacher" value="普通">普通   
        <input  type="radio" name="teacher" value="不滿意">不滿意   
        <input  type="radio" name="teacher" value="非常不滿意">非常不滿意
  </div>
   
  <hr width="80%"  align="left">
  <h2>備註欄(如有其他意見可在此處填寫)</h2>
  <div class="message"><textarea name="message" rows="10" cols="50"></textarea></div>
  
  </div>
     
  <div class="submit">
    <button  onclick="form.submit();" >提交回饋</button>
  </div>
     <div class="reser">
       <button  onclick="form.reset();" >重新填寫</button>
     </div>
    
      
 </div>

</form>
  </div>
   
    
</div>
  
  
    
</body>
</html>
